import pytest

pytestmark = pytest.mark.asyncio


async def test_create_project(client, auth_headers):
    resp = await client.post(
        "/api/v1/projects",
        json={"name": "Website Revamp", "key": "WEB", "description": "Marketing site redesign"},
        headers=auth_headers,
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["key"] == "WEB"
    assert data["owner"]["username"] == "testuser"


async def test_duplicate_project_key_rejected(client, auth_headers):
    payload = {"name": "Proj A", "key": "DUP"}
    await client.post("/api/v1/projects", json=payload, headers=auth_headers)
    resp = await client.post("/api/v1/projects", json={**payload, "name": "Proj B"}, headers=auth_headers)
    assert resp.status_code == 400


async def test_list_my_projects(client, auth_headers):
    await client.post("/api/v1/projects", json={"name": "P1", "key": "P1"}, headers=auth_headers)
    resp = await client.get("/api/v1/projects", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] >= 1


async def test_non_member_cannot_view_project(client, auth_headers):
    create_resp = await client.post("/api/v1/projects", json={"name": "Private", "key": "PRIV"}, headers=auth_headers)
    project_id = create_resp.json()["id"]

    await client.post(
        "/api/v1/auth/register",
        json={"email": "outsider@example.com", "username": "outsider", "password": "StrongPass1"},
    )
    login_resp = await client.post(
        "/api/v1/auth/login", data={"username": "outsider", "password": "StrongPass1"}
    )
    outsider_headers = {"Authorization": f"Bearer {login_resp.json()['access_token']}"}

    resp = await client.get(f"/api/v1/projects/{project_id}", headers=outsider_headers)
    assert resp.status_code == 403
