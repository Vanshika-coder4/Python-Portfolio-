import pytest

pytestmark = pytest.mark.asyncio


async def _create_project(client, auth_headers, key="TST"):
    resp = await client.post("/api/v1/projects", json={"name": "Test Project", "key": key}, headers=auth_headers)
    return resp.json()["id"]


async def test_create_and_get_task(client, auth_headers):
    project_id = await _create_project(client, auth_headers)
    resp = await client.post(
        f"/api/v1/projects/{project_id}/tasks",
        json={"title": "Set up CI pipeline", "priority": "high"},
        headers=auth_headers,
    )
    assert resp.status_code == 201
    task = resp.json()
    assert task["status"] == "todo"
    assert task["priority"] == "high"

    get_resp = await client.get(f"/api/v1/projects/{project_id}/tasks/{task['id']}", headers=auth_headers)
    assert get_resp.status_code == 200


async def test_update_task_status_sets_completed_at(client, auth_headers):
    project_id = await _create_project(client, auth_headers, key="TST2")
    create_resp = await client.post(
        f"/api/v1/projects/{project_id}/tasks", json={"title": "Ship feature"}, headers=auth_headers
    )
    task_id = create_resp.json()["id"]

    update_resp = await client.patch(
        f"/api/v1/projects/{project_id}/tasks/{task_id}", json={"status": "done"}, headers=auth_headers
    )
    assert update_resp.status_code == 200
    assert update_resp.json()["completed_at"] is not None


async def test_filter_tasks_by_status(client, auth_headers):
    project_id = await _create_project(client, auth_headers, key="TST3")
    await client.post(f"/api/v1/projects/{project_id}/tasks", json={"title": "A"}, headers=auth_headers)
    task2 = await client.post(f"/api/v1/projects/{project_id}/tasks", json={"title": "B"}, headers=auth_headers)
    await client.patch(
        f"/api/v1/projects/{project_id}/tasks/{task2.json()['id']}", json={"status": "done"}, headers=auth_headers
    )

    resp = await client.get(f"/api/v1/projects/{project_id}/tasks?status=done", headers=auth_headers)
    data = resp.json()
    assert data["total"] == 1
    assert data["items"][0]["title"] == "B"


async def test_search_tasks(client, auth_headers):
    project_id = await _create_project(client, auth_headers, key="TST4")
    await client.post(f"/api/v1/projects/{project_id}/tasks", json={"title": "Fix login bug"}, headers=auth_headers)
    await client.post(f"/api/v1/projects/{project_id}/tasks", json={"title": "Write docs"}, headers=auth_headers)

    resp = await client.get(f"/api/v1/projects/{project_id}/tasks?search=login", headers=auth_headers)
    data = resp.json()
    assert data["total"] == 1
    assert "login" in data["items"][0]["title"].lower()


async def test_delete_task(client, auth_headers):
    project_id = await _create_project(client, auth_headers, key="TST5")
    create_resp = await client.post(
        f"/api/v1/projects/{project_id}/tasks", json={"title": "Temp task"}, headers=auth_headers
    )
    task_id = create_resp.json()["id"]

    del_resp = await client.delete(f"/api/v1/projects/{project_id}/tasks/{task_id}", headers=auth_headers)
    assert del_resp.status_code == 200

    get_resp = await client.get(f"/api/v1/projects/{project_id}/tasks/{task_id}", headers=auth_headers)
    assert get_resp.status_code == 404
