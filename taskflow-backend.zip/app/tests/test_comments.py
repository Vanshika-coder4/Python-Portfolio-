import pytest

pytestmark = pytest.mark.asyncio


async def test_add_comment_to_task(client, auth_headers):
    project_resp = await client.post("/api/v1/projects", json={"name": "P", "key": "CMT"}, headers=auth_headers)
    project_id = project_resp.json()["id"]
    task_resp = await client.post(
        f"/api/v1/projects/{project_id}/tasks", json={"title": "Discuss design"}, headers=auth_headers
    )
    task_id = task_resp.json()["id"]

    resp = await client.post(
        f"/api/v1/projects/{project_id}/tasks/{task_id}/comments",
        json={"body": "Looks good to me!"},
        headers=auth_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["body"] == "Looks good to me!"

    list_resp = await client.get(
        f"/api/v1/projects/{project_id}/tasks/{task_id}/comments", headers=auth_headers
    )
    assert len(list_resp.json()) == 1
