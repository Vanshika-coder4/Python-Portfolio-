import pytest

pytestmark = pytest.mark.asyncio


async def test_register_user(client):
    resp = await client.post(
        "/api/v1/auth/register",
        json={"email": "alice@example.com", "username": "alice", "password": "StrongPass1"},
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["email"] == "alice@example.com"
    assert "hashed_password" not in data


async def test_register_duplicate_email_fails(client):
    payload = {"email": "bob@example.com", "username": "bob", "password": "StrongPass1"}
    await client.post("/api/v1/auth/register", json=payload)
    resp = await client.post("/api/v1/auth/register", json={**payload, "username": "bob2"})
    assert resp.status_code == 400


async def test_login_success(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "carol@example.com", "username": "carol", "password": "StrongPass1"},
    )
    resp = await client.post(
        "/api/v1/auth/login", data={"username": "carol", "password": "StrongPass1"}
    )
    assert resp.status_code == 200
    assert "access_token" in resp.json()
    assert "refresh_token" in resp.json()


async def test_login_wrong_password_fails(client):
    await client.post(
        "/api/v1/auth/register",
        json={"email": "dave@example.com", "username": "dave", "password": "StrongPass1"},
    )
    resp = await client.post("/api/v1/auth/login", data={"username": "dave", "password": "wrong"})
    assert resp.status_code == 401


async def test_me_requires_auth(client):
    resp = await client.get("/api/v1/auth/me")
    assert resp.status_code == 401


async def test_me_with_valid_token(client, auth_headers):
    resp = await client.get("/api/v1/auth/me", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["username"] == "testuser"
