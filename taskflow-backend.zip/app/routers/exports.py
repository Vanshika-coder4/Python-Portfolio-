"""
CSV export endpoint and file attachment upload/download for tasks.
"""
import os
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.attachment import Attachment
from app.models.project import ProjectMember
from app.models.task import Task
from app.models.user import User
from app.schemas.common import MessageResponse
from app.services.export import tasks_to_csv

router = APIRouter(tags=["Exports & Files"])


@router.get("/projects/{project_id}/export/csv")
async def export_project_csv(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    member = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == current_user.id)
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Not a member of this project")

    result = await db.execute(
        select(Task).where(Task.project_id == project_id).options(selectinload(Task.assignee))
    )
    csv_data = tasks_to_csv(result.scalars().all())
    return StreamingResponse(
        iter([csv_data]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=project_{project_id}_tasks.csv"},
    )


@router.post("/projects/{project_id}/tasks/{task_id}/attachments", response_model=MessageResponse)
async def upload_attachment(
    project_id: int,
    task_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    file: UploadFile = File(...),
):
    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > settings.MAX_UPLOAD_SIZE_MB:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.MAX_UPLOAD_SIZE_MB}MB limit")

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    stored_name = f"{uuid.uuid4().hex}_{file.filename}"
    path = os.path.join(settings.UPLOAD_DIR, stored_name)
    with open(path, "wb") as f:
        f.write(contents)

    db.add(
        Attachment(
            task_id=task_id,
            uploader_id=current_user.id,
            filename=file.filename,
            storage_path=path,
            content_type=file.content_type or "application/octet-stream",
            size_bytes=len(contents),
        )
    )
    await db.commit()
    return MessageResponse(message="File uploaded")
