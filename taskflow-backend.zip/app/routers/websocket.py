"""
WebSocket endpoint for real-time notifications and live task/comment updates.
Auth via JWT passed as a query param (browsers can't set headers on WS handshake).
"""
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status

from app.core.database import AsyncSessionLocal
from app.core.security import decode_token
from app.core.websocket_manager import manager
from app.models.user import User
from sqlalchemy import select

router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str):
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).where(User.id == int(payload["sub"])))
        user = result.scalar_one_or_none()

    if not user or not user.is_active:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await manager.connect(websocket, user.id)
    try:
        while True:
            # Currently server -> client push only; client messages are read but unused
            # (kept alive so the connection doesn't idle-timeout on some proxies)
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, user.id)
