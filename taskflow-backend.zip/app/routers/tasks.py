"""
Task CRUD, filtering/search, status transitions with real-time + notification side-effects.
"""
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.dependencies import PaginationParams, get_current_user
from app.core.websocket_manager import manager
from app.models.notification import Notification, NotificationType
from app.models.project import ProjectMember
from app.models.task import Task, TaskPriority, TaskStatus
from app.models.user import User
from app.schemas.common import MessageResponse, PaginatedResponse
from app.schemas.task import TaskCreate, TaskRead, TaskUpdate
from app.tasks.background_tasks import send_task_assignment_email

router = APIRouter(prefix="/projects/{project_id}/tasks", tags=["Tasks"])


async def _require_membership(project_id: int, user: User, db: AsyncSession) -> ProjectMember:
    result = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == user.id)
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=403, detail="Not a member of this project")
    return member


async def _notify(db: AsyncSession, recipient_id: int, ntype: NotificationType, message: str, link: str | None = None):
    notif = Notification(recipient_id=recipient_id, type=ntype, message=message, link=link)
    db.add(notif)
    await db.flush()
    await manager.send_to_user(
        recipient_id,
        {"event": "notification", "type": ntype.value, "message": message, "link": link, "id": notif.id},
    )


@router.post("", response_model=TaskRead, status_code=status.HTTP_201_CREATED)
async def create_task(
    project_id: int,
    payload: TaskCreate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)

    task = Task(**payload.model_dump(), project_id=project_id, creator_id=current_user.id)
    db.add(task)
    await db.flush()

    if task.assignee_id and task.assignee_id != current_user.id:
        await _notify(
            db, task.assignee_id, NotificationType.TASK_ASSIGNED,
            f"{current_user.username} assigned you to '{task.title}'",
            link=f"/projects/{project_id}/tasks/{task.id}",
        )
        send_task_assignment_email.delay(task.assignee_id, task.id)

    await db.commit()
    await db.refresh(task, attribute_names=["creator", "assignee"])

    await manager.send_to_user(current_user.id, {"event": "task_created", "task_id": task.id, "project_id": project_id})
    return task


@router.get("", response_model=PaginatedResponse[TaskRead])
async def list_tasks(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    pagination: Annotated[PaginationParams, Depends()],
    status_filter: TaskStatus | None = Query(None, alias="status"),
    priority: TaskPriority | None = None,
    assignee_id: int | None = None,
    search: str | None = Query(None, min_length=1, max_length=200),
):
    await _require_membership(project_id, current_user, db)

    query = select(Task).where(Task.project_id == project_id).options(
        selectinload(Task.creator), selectinload(Task.assignee)
    )
    if status_filter:
        query = query.where(Task.status == status_filter)
    if priority:
        query = query.where(Task.priority == priority)
    if assignee_id:
        query = query.where(Task.assignee_id == assignee_id)
    if search:
        like = f"%{search}%"
        query = query.where(or_(Task.title.ilike(like), Task.description.ilike(like)))

    total = (await db.execute(select(func.count()).select_from(query.subquery()))).scalar_one()
    result = await db.execute(query.order_by(Task.created_at.desc()).offset(pagination.offset).limit(pagination.limit))
    tasks = result.scalars().all()

    pages = (total + pagination.page_size - 1) // pagination.page_size if total else 0
    return PaginatedResponse(items=tasks, total=total, page=pagination.page, page_size=pagination.page_size, pages=pages)


async def _get_task_or_404(project_id: int, task_id: int, db: AsyncSession) -> Task:
    result = await db.execute(
        select(Task)
        .where(Task.id == task_id, Task.project_id == project_id)
        .options(selectinload(Task.creator), selectinload(Task.assignee))
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@router.get("/{task_id}", response_model=TaskRead)
async def get_task(
    project_id: int,
    task_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)
    return await _get_task_or_404(project_id, task_id, db)


@router.patch("/{task_id}", response_model=TaskRead)
async def update_task(
    project_id: int,
    task_id: int,
    payload: TaskUpdate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)
    task = await _get_task_or_404(project_id, task_id, db)

    updates = payload.model_dump(exclude_unset=True)
    old_status, old_assignee = task.status, task.assignee_id

    for field, value in updates.items():
        setattr(task, field, value)

    if "status" in updates and task.status == TaskStatus.DONE and old_status != TaskStatus.DONE:
        from datetime import datetime, timezone
        task.completed_at = datetime.now(timezone.utc)

    await db.flush()

    if "status" in updates and updates["status"] != old_status and task.assignee_id:
        await _notify(
            db, task.assignee_id, NotificationType.TASK_STATUS_CHANGED,
            f"'{task.title}' moved to {task.status.value.replace('_', ' ')}",
            link=f"/projects/{project_id}/tasks/{task.id}",
        )
    if "assignee_id" in updates and updates["assignee_id"] and updates["assignee_id"] != old_assignee:
        await _notify(
            db, task.assignee_id, NotificationType.TASK_ASSIGNED,
            f"{current_user.username} assigned you to '{task.title}'",
            link=f"/projects/{project_id}/tasks/{task.id}",
        )

    await db.commit()
    await db.refresh(task, attribute_names=["creator", "assignee"])

    await manager.broadcast_to_users(
        [m async for m in _member_ids(project_id, db)],
        {"event": "task_updated", "task_id": task.id, "project_id": project_id, "status": task.status.value},
    )
    return task


async def _member_ids(project_id: int, db: AsyncSession):
    result = await db.execute(select(ProjectMember.user_id).where(ProjectMember.project_id == project_id))
    for (uid,) in result.all():
        yield uid


@router.delete("/{task_id}", response_model=MessageResponse)
async def delete_task(
    project_id: int,
    task_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)
    task = await _get_task_or_404(project_id, task_id, db)
    await db.delete(task)
    await db.commit()
    return MessageResponse(message="Task deleted")
