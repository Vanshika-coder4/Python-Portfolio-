"""
Comments on tasks, with @mention detection triggering notifications.
"""
import re
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.core.websocket_manager import manager
from app.models.comment import Comment
from app.models.notification import Notification, NotificationType
from app.models.project import ProjectMember
from app.models.task import Task
from app.models.user import User
from app.schemas.comment import CommentCreate, CommentRead
from app.schemas.common import MessageResponse

router = APIRouter(prefix="/projects/{project_id}/tasks/{task_id}/comments", tags=["Comments"])

MENTION_RE = re.compile(r"@(\w+)")


async def _require_membership(project_id: int, user: User, db: AsyncSession):
    result = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == user.id)
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Not a member of this project")


@router.post("", response_model=CommentRead, status_code=201)
async def create_comment(
    project_id: int,
    task_id: int,
    payload: CommentCreate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)

    task_result = await db.execute(select(Task).where(Task.id == task_id, Task.project_id == project_id))
    task = task_result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    comment = Comment(body=payload.body, task_id=task_id, author_id=current_user.id)
    db.add(comment)
    await db.flush()

    # Notify task assignee (if not the author)
    if task.assignee_id and task.assignee_id != current_user.id:
        notif = Notification(
            recipient_id=task.assignee_id,
            type=NotificationType.NEW_COMMENT,
            message=f"{current_user.username} commented on '{task.title}'",
            link=f"/projects/{project_id}/tasks/{task_id}",
        )
        db.add(notif)
        await manager.send_to_user(task.assignee_id, {"event": "notification", "type": "new_comment", "message": notif.message})

    # Notify @mentioned users in this project
    mentioned_usernames = set(MENTION_RE.findall(payload.body))
    if mentioned_usernames:
        users_result = await db.execute(select(User).where(User.username.in_(mentioned_usernames)))
        for user in users_result.scalars().all():
            if user.id == current_user.id:
                continue
            notif = Notification(
                recipient_id=user.id,
                type=NotificationType.MENTIONED,
                message=f"{current_user.username} mentioned you on '{task.title}'",
                link=f"/projects/{project_id}/tasks/{task_id}",
            )
            db.add(notif)
            await manager.send_to_user(user.id, {"event": "notification", "type": "mentioned", "message": notif.message})

    await db.commit()
    await db.refresh(comment, attribute_names=["author"])

    await manager.broadcast_to_users(
        [task.assignee_id] if task.assignee_id else [],
        {"event": "new_comment", "task_id": task_id, "comment_id": comment.id},
    )
    return comment


@router.get("", response_model=list[CommentRead])
async def list_comments(
    project_id: int,
    task_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)
    result = await db.execute(
        select(Comment)
        .where(Comment.task_id == task_id)
        .options(selectinload(Comment.author))
        .order_by(Comment.created_at.asc())
    )
    return result.scalars().all()


@router.delete("/{comment_id}", response_model=MessageResponse)
async def delete_comment(
    project_id: int,
    task_id: int,
    comment_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    result = await db.execute(select(Comment).where(Comment.id == comment_id, Comment.task_id == task_id))
    comment = result.scalar_one_or_none()
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    if comment.author_id != current_user.id:
        raise HTTPException(status_code=403, detail="Cannot delete another user's comment")
    await db.delete(comment)
    await db.commit()
    return MessageResponse(message="Comment deleted")
