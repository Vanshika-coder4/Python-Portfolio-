"""
Project CRUD + membership management.
"""
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.cache import cached, invalidate_prefix
from app.core.database import get_db
from app.core.dependencies import PaginationParams, get_current_user
from app.models.project import Project, ProjectMember, ProjectRole
from app.models.task import Task
from app.models.user import User
from app.schemas.common import MessageResponse, PaginatedResponse
from app.schemas.project import (
    AddMemberRequest,
    ProjectCreate,
    ProjectDetail,
    ProjectRead,
    ProjectUpdate,
)

router = APIRouter(prefix="/projects", tags=["Projects"])


async def _get_project_or_404(project_id: int, db: AsyncSession) -> Project:
    result = await db.execute(
        select(Project).options(selectinload(Project.members).selectinload(ProjectMember.user), selectinload(Project.owner))
        .where(Project.id == project_id)
    )
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


async def _require_membership(project_id: int, user: User, db: AsyncSession, roles: set[ProjectRole] | None = None):
    result = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == user.id)
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=403, detail="Not a member of this project")
    if roles and member.role not in roles:
        raise HTTPException(status_code=403, detail="Insufficient permissions for this action")
    return member


@router.post("", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
async def create_project(
    payload: ProjectCreate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    existing = await db.execute(select(Project).where(Project.key == payload.key))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Project key already in use")

    project = Project(name=payload.name, description=payload.description, key=payload.key, owner_id=current_user.id)
    db.add(project)
    await db.flush()

    db.add(ProjectMember(project_id=project.id, user_id=current_user.id, role=ProjectRole.OWNER))
    await db.commit()
    await db.refresh(project)
    project.owner = current_user
    return ProjectRead.model_validate(project, from_attributes=True)


@router.get("", response_model=PaginatedResponse[ProjectRead])
async def list_my_projects(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    pagination: Annotated[PaginationParams, Depends()],
):
    base_query = (
        select(Project)
        .join(ProjectMember, ProjectMember.project_id == Project.id)
        .where(ProjectMember.user_id == current_user.id)
        .options(selectinload(Project.owner))
    )
    total = (await db.execute(select(func.count()).select_from(base_query.subquery()))).scalar_one()
    result = await db.execute(base_query.offset(pagination.offset).limit(pagination.limit))
    projects = result.scalars().all()

    items = []
    for p in projects:
        count_result = await db.execute(select(func.count()).select_from(Task).where(Task.project_id == p.id))
        item = ProjectRead.model_validate(p, from_attributes=True)
        item.task_count = count_result.scalar_one()
        items.append(item)

    pages = (total + pagination.page_size - 1) // pagination.page_size if total else 0
    return PaginatedResponse(items=items, total=total, page=pagination.page, page_size=pagination.page_size, pages=pages)


@router.get("/{project_id}", response_model=ProjectDetail)
async def get_project(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db)
    project = await _get_project_or_404(project_id, db)
    return project


@router.patch("/{project_id}", response_model=ProjectRead)
async def update_project(
    project_id: int,
    payload: ProjectUpdate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db, roles={ProjectRole.OWNER, ProjectRole.ADMIN})
    project = await _get_project_or_404(project_id, db)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(project, field, value)
    await db.commit()
    await db.refresh(project)
    await invalidate_prefix("projects")
    return project


@router.delete("/{project_id}", response_model=MessageResponse)
async def delete_project(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db, roles={ProjectRole.OWNER})
    project = await _get_project_or_404(project_id, db)
    await db.delete(project)
    await db.commit()
    return MessageResponse(message="Project deleted")


@router.post("/{project_id}/members", response_model=MessageResponse)
async def add_member(
    project_id: int,
    payload: AddMemberRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db, roles={ProjectRole.OWNER, ProjectRole.ADMIN})

    existing = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == payload.user_id)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="User is already a member")

    db.add(ProjectMember(project_id=project_id, user_id=payload.user_id, role=payload.role))
    await db.commit()
    return MessageResponse(message="Member added")


@router.delete("/{project_id}/members/{user_id}", response_model=MessageResponse)
async def remove_member(
    project_id: int,
    user_id: int,
    current_user: Annotated[User, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
):
    await _require_membership(project_id, current_user, db, roles={ProjectRole.OWNER, ProjectRole.ADMIN})
    result = await db.execute(
        select(ProjectMember).where(ProjectMember.project_id == project_id, ProjectMember.user_id == user_id)
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    if member.role == ProjectRole.OWNER:
        raise HTTPException(status_code=400, detail="Cannot remove the project owner")
    await db.delete(member)
    await db.commit()
    return MessageResponse(message="Member removed")
