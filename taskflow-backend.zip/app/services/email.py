"""
Minimal async SMTP email sender. Swap for a provider SDK (SES/SendGrid) in production.
"""
import logging

import aiosmtplib
from email.message import EmailMessage

from app.core.config import settings

logger = logging.getLogger(__name__)


async def send_email(to: str, subject: str, body: str) -> None:
    message = EmailMessage()
    message["From"] = settings.EMAILS_FROM_EMAIL
    message["To"] = to
    message["Subject"] = subject
    message.set_content(body)

    if settings.ENVIRONMENT == "development":
        logger.info("DEV EMAIL to=%s subject=%s body=%s", to, subject, body)
        return

    await aiosmtplib.send(
        message,
        hostname=settings.SMTP_HOST,
        port=settings.SMTP_PORT,
        username=settings.SMTP_USER or None,
        password=settings.SMTP_PASSWORD or None,
        start_tls=True,
    )
