"""
CSV/PDF export helpers for project task reports.
"""
import csv
import io

from app.models.task import Task


def tasks_to_csv(tasks: list[Task]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["ID", "Title", "Status", "Priority", "Assignee", "Due Date"])
    for t in tasks:
        writer.writerow([
            t.id,
            t.title,
            t.status.value,
            t.priority.value,
            t.assignee.username if t.assignee else "",
            t.due_date.isoformat() if t.due_date else "",
        ])
    return buffer.getvalue()
