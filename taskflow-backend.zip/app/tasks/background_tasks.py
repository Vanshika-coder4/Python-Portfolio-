"""
Celery tasks: transactional emails, scheduled reminders, exports.
These run out-of-process so API requests stay fast.
"""
import asyncio
from datetime import datetime, timedelta, timezone

from app.core.config import settings
from app.services.email import send_email
from app.tasks.celery_app import celery_app


@celery_app.task(name="app.tasks.background_tasks.send_task_assignment_email", bind=True, max_retries=3)
def send_task_assignment_email(self, user_id: int, task_id: int):
    """Notify a user by email that they were assigned a task."""
    from app.core.database import AsyncSessionLocal
    from app.models.task import Task
    from app.models.user import User
    from sqlalchemy import select

    async def _run():
        async with AsyncSessionLocal() as db:
            user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
            task = (await db.execute(select(Task).where(Task.id == task_id))).scalar_one_or_none()
            if not user or not task:
                return
            await send_email(
                to=user.email,
                subject=f"You've been assigned: {task.title}",
                body=f"Hi {user.username}, you were assigned to task '{task.title}'.",
            )

    try:
        asyncio.run(_run())
    except Exception as exc:
        raise self.retry(exc=exc, countdown=60)


@celery_app.task(name="app.tasks.background_tasks.send_due_date_reminders")
def send_due_date_reminders():
    """Scheduled (Celery beat) job: email users whose tasks are due within 24h."""
    from app.core.database import AsyncSessionLocal
    from app.models.notification import Notification, NotificationType
    from app.models.task import Task, TaskStatus
    from sqlalchemy import select

    async def _run():
        soon = datetime.now(timezone.utc) + timedelta(hours=24)
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(Task).where(
                    Task.due_date.is_not(None),
                    Task.due_date <= soon,
                    Task.status != TaskStatus.DONE,
                    Task.assignee_id.is_not(None),
                )
            )
            tasks = result.scalars().all()
            for task in tasks:
                db.add(
                    Notification(
                        recipient_id=task.assignee_id,
                        type=NotificationType.DUE_DATE_REMINDER,
                        message=f"'{task.title}' is due soon",
                        link=f"/projects/{task.project_id}/tasks/{task.id}",
                    )
                )
            await db.commit()

    asyncio.run(_run())


@celery_app.task(name="app.tasks.background_tasks.export_project_report")
def export_project_report(project_id: int, requested_by_user_id: int, fmt: str = "csv"):
    """Generate a CSV/PDF export of a project's tasks and email it (or store it) for download."""
    # Implementation would query tasks, build the file via pandas/reportlab,
    # store to S3/local disk, then notify the user with a download link.
    return {"project_id": project_id, "format": fmt, "status": "completed"}
