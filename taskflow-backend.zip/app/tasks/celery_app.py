"""
Celery application for background jobs (emails, reminders, exports).
Run a worker with: celery -A app.tasks.celery_app worker --loglevel=info
Run the beat scheduler with: celery -A app.tasks.celery_app beat --loglevel=info
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "taskflow",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.tasks.background_tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,
)

celery_app.conf.beat_schedule = {
    "send-due-date-reminders-every-hour": {
        "task": "app.tasks.background_tasks.send_due_date_reminders",
        "schedule": crontab(minute=0),  # every hour on the hour
    },
}
