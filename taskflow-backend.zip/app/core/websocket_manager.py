"""
In-memory WebSocket connection manager, keyed by user_id.
Broadcasts real-time notifications, task updates, and comment events.
For multi-instance deployments this can be backed by Redis pub/sub (see notify_via_redis).
"""
import json
from typing import Any

from fastapi import WebSocket


class ConnectionManager:
    def __init__(self) -> None:
        self.active_connections: dict[int, list[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: int) -> None:
        await websocket.accept()
        self.active_connections.setdefault(user_id, []).append(websocket)

    def disconnect(self, websocket: WebSocket, user_id: int) -> None:
        conns = self.active_connections.get(user_id, [])
        if websocket in conns:
            conns.remove(websocket)
        if not conns and user_id in self.active_connections:
            del self.active_connections[user_id]

    async def send_to_user(self, user_id: int, message: dict[str, Any]) -> None:
        for ws in self.active_connections.get(user_id, []):
            await ws.send_text(json.dumps(message, default=str))

    async def broadcast_to_users(self, user_ids: list[int], message: dict[str, Any]) -> None:
        for uid in user_ids:
            await self.send_to_user(uid, message)

    async def broadcast_all(self, message: dict[str, Any]) -> None:
        for uid in list(self.active_connections.keys()):
            await self.send_to_user(uid, message)


manager = ConnectionManager()
