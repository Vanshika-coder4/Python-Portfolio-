"""
Thin Redis cache wrapper with a decorator for caching endpoint/service results.
Falls back gracefully if Redis is unreachable (useful for local dev without Redis).
"""
import json
import functools
import hashlib
from typing import Any, Callable

import redis.asyncio as aioredis

from app.core.config import settings

_redis_client: aioredis.Redis | None = None


async def get_redis() -> aioredis.Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    return _redis_client


def _make_key(prefix: str, args: tuple, kwargs: dict) -> str:
    raw = f"{prefix}:{args}:{sorted(kwargs.items())}"
    return f"taskflow:{prefix}:{hashlib.sha256(raw.encode()).hexdigest()[:24]}"


def cached(prefix: str, ttl_seconds: int = 60):
    """Decorator to cache the JSON-serializable return value of an async function in Redis."""

    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                r = await get_redis()
                key = _make_key(prefix, args, kwargs)
                cached_val = await r.get(key)
                if cached_val is not None:
                    return json.loads(cached_val)
                result = await func(*args, **kwargs)
                await r.set(key, json.dumps(result, default=str), ex=ttl_seconds)
                return result
            except Exception:
                # Redis unavailable -> just run the function uncached
                return await func(*args, **kwargs)

        return wrapper

    return decorator


async def invalidate_prefix(prefix: str) -> None:
    try:
        r = await get_redis()
        async for key in r.scan_iter(match=f"taskflow:{prefix}:*"):
            await r.delete(key)
    except Exception:
        pass
