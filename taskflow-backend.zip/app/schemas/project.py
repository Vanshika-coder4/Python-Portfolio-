from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models.project import ProjectRole
from app.schemas.user import UserPublic


class ProjectBase(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    description: str | None = None


class ProjectCreate(ProjectBase):
    key: str = Field(min_length=2, max_length=10, pattern=r"^[A-Z0-9]+$")


class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    is_archived: bool | None = None


class ProjectMemberRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    user: UserPublic
    role: ProjectRole
    joined_at: datetime


class ProjectRead(ProjectBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    key: str
    is_archived: bool
    owner: UserPublic
    created_at: datetime
    task_count: int = 0


class ProjectDetail(ProjectRead):
    members: list[ProjectMemberRead] = []


class AddMemberRequest(BaseModel):
    user_id: int
    role: ProjectRole = ProjectRole.MEMBER
