# TaskFlow — Backend API

A collaborative project & task management platform. This is the backend service:
a FastAPI application with async SQLAlchemy, JWT auth, WebSocket-based real-time
notifications, Celery background jobs, Redis caching, and a fully containerized
dev/prod setup with CI/CD.

## Stack

| Layer            | Technology                                   |
|-------------------|-----------------------------------------------|
| API framework     | FastAPI (async), Uvicorn                      |
| Database          | PostgreSQL + SQLAlchemy 2.0 (async ORM)        |
| Migrations        | Alembic                                       |
| Auth              | JWT (access + refresh tokens), bcrypt hashing |
| Real-time         | Native WebSockets, in-memory connection manager |
| Background jobs   | Celery + Redis (broker/result backend) + beat |
| Caching           | Redis                                         |
| Testing           | Pytest, pytest-asyncio, httpx, 80%+ coverage gate |
| Containerization  | Docker multi-stage build, docker-compose      |
| CI/CD             | GitHub Actions (lint → test → security scan → build → deploy) |

## Features

- **Auth & authorization** — register/login/refresh, bcrypt password hashing, role-based
  project membership (owner/admin/member/viewer).
- **Projects & tasks** — full CRUD, subtasks (self-referential FK), status/priority
  enums, filtering, search, and pagination.
- **Comments & @mentions** — comments on tasks auto-notify the assignee and any
  `@username` mentioned in the body.
- **Real-time notifications** — WebSocket endpoint (`/api/v1/ws`) pushes task
  assignment, status change, comment, and mention events live to connected clients.
- **Background jobs** — Celery handles assignment emails and an hourly due-date
  reminder sweep via Celery beat.
- **File attachments & CSV export** — upload files to tasks; export a project's
  tasks as CSV.
- **Caching** — Redis-backed `@cached` decorator with prefix-based invalidation.
- **Security** — JWT expiry, bcrypt, CORS allowlist, request size limits, Bandit +
  pip-audit in CI.

## Project layout

```
taskflow-backend/
├── app/
│   ├── core/            # config, database, security, cache, websocket manager, deps
│   ├── models/           # SQLAlchemy ORM models (User, Project, Task, Comment, ...)
│   ├── schemas/          # Pydantic request/response models
│   ├── routers/           # API route handlers (auth, projects, tasks, comments, ...)
│   ├── services/           # email, CSV export helpers
│   ├── tasks/               # Celery app + background jobs
│   ├── tests/                 # Pytest suite
│   └── main.py                  # FastAPI app assembly
├── alembic/                       # DB migrations
├── Dockerfile                       # Multi-stage build
├── docker-compose.yml                 # api + worker + beat + postgres + redis
├── .github/workflows/ci-cd.yml          # Lint, test, scan, build, deploy
├── requirements.txt / requirements-dev.txt
└── .env.example
```

## Getting started (Docker — recommended)

```bash
cp .env.example .env        # edit SECRET_KEY at minimum
docker compose up --build
```

- API: http://localhost:8000
- Swagger docs: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Getting started (local, without Docker)

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
# point DATABASE_URL at a local Postgres, or use the SQLite test DB for quick exploration

alembic upgrade head          # apply migrations (production-style)
uvicorn app.main:app --reload

# in separate terminals, for background jobs:
celery -A app.tasks.celery_app worker --loglevel=info
celery -A app.tasks.celery_app beat --loglevel=info
```

## Running tests

```bash
pytest                         # runs full suite with coverage (gate: 80%)
pytest --cov=app --cov-report=html   # HTML report in htmlcov/
```

## API overview

All routes are versioned under `/api/v1`.

| Resource       | Endpoints (highlights)                                             |
|----------------|----------------------------------------------------------------------|
| Auth           | `POST /auth/register`, `POST /auth/login`, `POST /auth/refresh`, `GET /auth/me` |
| Projects       | `POST/GET /projects`, `GET/PATCH/DELETE /projects/{id}`, member management |
| Tasks          | `POST/GET /projects/{id}/tasks`, `PATCH/DELETE .../tasks/{id}`, filter by status/priority/assignee/search |
| Comments       | `POST/GET/DELETE .../tasks/{id}/comments`                            |
| Notifications  | `GET /notifications`, `POST /notifications/{id}/read`                |
| Exports/Files  | `GET /projects/{id}/export/csv`, `POST .../tasks/{id}/attachments`   |
| Real-time      | `WS /ws?token=<access_token>`                                        |

Full interactive schema is auto-generated at `/docs` (OpenAPI/Swagger).

## Database design notes

- `ProjectMember` is an **association object** (not a plain many-to-many table) so
  each membership carries a `role`, enabling role-based authorization per project.
- `Task` has a self-referential FK (`parent_task_id`) to support subtasks.
- Composite indexes on `(project_id, status)` and `(assignee_id, status)` optimize
  the board/list-filtering queries that dominate this app's read traffic.
- Cascades: deleting a project cascades to its tasks; deleting a task cascades to
  its comments/attachments; deleting a user preserves historical tasks/comments via
  `SET NULL` on `creator_id`/`author_id`.

## Deployment

The CI/CD pipeline (`.github/workflows/ci-cd.yml`) lints, tests with coverage,
runs Bandit/pip-audit security scans, builds a multi-stage Docker image, pushes it
to GitHub Container Registry, and triggers a deploy hook on `main`. Point
`DEPLOY_HOOK_URL` at your platform of choice (Railway, Render, Fly.io, AWS ECS).

For production, set `ENVIRONMENT=production`, `DEBUG=false`, a strong `SECRET_KEY`,
and run `alembic upgrade head` instead of relying on `init_db()`'s dev-only
`create_all`.
