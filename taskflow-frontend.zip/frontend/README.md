# TaskFlow — Frontend

The client for **TaskFlow**, a collaborative project & task management platform. Built with React 18, TypeScript, and Vite; talks to a Python REST + WebSocket backend (see `../backend`).

This folder is the frontend half of the full-stack capstone project — it pairs with a FastAPI/Flask backend providing auth, persistence, and real-time events over Socket.IO.

## Stack

| Concern | Choice |
|---|---|
| Framework | React 18 + TypeScript, bundled with Vite |
| Routing | React Router v6 (lazy-loaded routes) |
| State | Redux Toolkit (auth, projects, tasks, notifications, UI/theme) |
| Data fetching | Axios, with JWT access/refresh interceptors |
| Real-time | Socket.IO client, dispatched into Redux |
| Forms & validation | Controlled inputs + Zod schemas |
| Charts | Recharts |
| Testing | Vitest + React Testing Library |
| Styling | Plain CSS with a design-token system (no framework lock-in) |

## Getting started

```bash
cp .env.example .env      # point VITE_API_PROXY_TARGET at your backend
npm install
npm run dev                # http://localhost:5173
```

Vite proxies `/api` and `/socket.io` to `VITE_API_PROXY_TARGET` in dev, so the frontend and backend can run on separate ports without CORS headaches.

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Start the dev server with HMR |
| `npm run build` | Type-check and produce a production build in `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run lint` | ESLint across the codebase |
| `npm test` | Run the Vitest suite once |
| `npm run test:watch` | Run tests in watch mode |
| `npm run test:coverage` | Run tests with a coverage report |
| `npm run format` | Prettier write |

## Project structure

```
src/
  api/          Axios client + one module per resource (auth, projects, tasks)
  components/
    common/     Button, Field, Modal, Spinner, StatusBadge, ErrorBoundary
    layout/     Sidebar, Navbar, NotificationsPanel, Layout shell
    tasks/      TaskCard, TaskBoard (kanban + drag/drop), TaskForm, filters
    projects/   ProjectCard
    charts/     Recharts-based status breakdown
  hooks/        useAuth, useWebSocket, useDebounce
  pages/        Route-level screens (Login, Dashboard, Projects, ...)
  routes/       AppRoutes, ProtectedRoute
  store/        Redux Toolkit store + slices (auth, projects, tasks, ui, notifications)
  styles/       globals.css — design tokens and shared classes
  types/        Shared TypeScript interfaces mirroring the API schema
  utils/        formatDate, validators
```

## Design system

The visual language treats each task as a **work order** moving through a shop-floor pipeline: dark blueprint-grid background, amber "routing trace" accents on cards and the kanban board header, monospace type for IDs/timestamps, and a Space Grotesk display face. Tokens live as CSS variables in `src/styles/globals.css`, including a `[data-theme="light"]` override for light mode. Focus states and `prefers-reduced-motion` are respected throughout.

## State & real-time data flow

1. REST calls go through `src/api/client.ts`, which attaches the JWT access token and transparently refreshes it on a 401 before retrying the original request once.
2. `useWebSocket` opens a single authenticated Socket.IO connection after login and dispatches `task:updated`, `task:deleted`, and `notification:new` events straight into the Redux store, so a change made by one teammate appears on another teammate's board without a refresh.
3. Kanban drag-and-drop updates status optimistically (`moveTask` sets local state in `pending`, then reconciles with the server response in `fulfilled`), so the UI never feels laggy even on a slow connection.

## Testing

`npm run test:coverage` runs unit tests for Redux slices, utility functions, and components (see `src/**/__tests__`). CI (`.github/workflows/ci.yml`) runs lint, type-check, tests with coverage, and a production build on every push, then builds the Docker image on `main`.

## Docker

```bash
docker build -t taskflow-frontend .
docker run -p 8080:80 taskflow-frontend
```

The multi-stage `Dockerfile` builds the Vite bundle with Node, then serves the static files with nginx (`nginx.conf`), which also reverse-proxies `/api` and `/socket.io` to a `backend` service — matching the service name expected in the project's `docker-compose.yml`.

## Accessibility

- Every interactive element has a visible focus ring (`:focus-visible`)
- Forms use associated `<label>`s, `aria-invalid`, and `aria-describedby` for errors
- The modal traps focus, closes on `Escape`, and is announced via `role="dialog"`/`aria-modal`
- Color is never the only signal — status badges pair color with text labels
- Respects `prefers-reduced-motion`

## Environment variables

See `.env.example`. `VITE_API_BASE_URL` and `VITE_WS_URL` are baked in at build time (standard for Vite); pass them as Docker build args or set them in your CI/CD pipeline per environment.
