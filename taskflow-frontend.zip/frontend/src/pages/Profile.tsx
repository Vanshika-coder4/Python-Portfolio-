import { useAuth } from "@/hooks/useAuth";

export default function Profile() {
  const { user } = useAuth();

  return (
    <div>
      <p className="eyebrow">Profile</p>
      <h1 style={{ fontSize: 26, marginTop: 6, marginBottom: 20 }}>Account</h1>

      <div className="work-card" style={{ maxWidth: 420 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: "50%",
              background: "var(--accent-teal-dim)",
              color: "var(--accent-teal)",
              display: "grid",
              placeItems: "center",
              fontWeight: 700,
              fontFamily: "var(--font-mono)",
            }}
          >
            {user?.fullName?.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <h3 style={{ fontSize: 16 }}>{user?.fullName}</h3>
            <p style={{ fontSize: 13 }}>{user?.email}</p>
          </div>
        </div>

        <dl style={{ marginTop: 18, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, fontSize: 13 }}>
          <div>
            <dt className="eyebrow">Role</dt>
            <dd style={{ margin: 0, marginTop: 2 }}>{user?.role}</dd>
          </div>
          <div>
            <dt className="eyebrow">Member since</dt>
            <dd style={{ margin: 0, marginTop: 2 }}>
              {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "—"}
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
