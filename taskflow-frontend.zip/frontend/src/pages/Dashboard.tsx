import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { fetchTasks } from "@/store/slices/tasksSlice";
import { fetchProjects } from "@/store/slices/projectsSlice";
import { StatusBreakdownChart } from "@/components/charts/StatusBreakdownChart";
import { useAuth } from "@/hooks/useAuth";

export default function Dashboard() {
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const tasks = useAppSelector((state) => state.tasks.items);
  const projects = useAppSelector((state) => state.projects.items);

  useEffect(() => {
    dispatch(fetchTasks({}));
    dispatch(fetchProjects());
  }, [dispatch]);

  const dueSoon = tasks.filter((t) => {
    if (!t.dueDate || t.status === "done") return false;
    const daysAway = (new Date(t.dueDate).getTime() - Date.now()) / 86_400_000;
    return daysAway >= 0 && daysAway <= 3;
  });

  const stats = [
    { label: "Active projects", value: projects.length },
    { label: "Open work orders", value: tasks.filter((t) => t.status !== "done").length },
    { label: "Due within 3 days", value: dueSoon.length },
    { label: "Closed this cycle", value: tasks.filter((t) => t.status === "done").length },
  ];

  return (
    <div>
      <p className="eyebrow">Dashboard</p>
      <h1 style={{ fontSize: 26, marginTop: 6, marginBottom: 24 }}>
        Welcome back{user ? `, ${user.fullName.split(" ")[0]}` : ""}.
      </h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
          gap: 14,
          marginBottom: 28,
        }}
      >
        {stats.map((s) => (
          <div key={s.label} className="work-card">
            <span className="eyebrow">{s.label}</span>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 30, marginTop: 6 }}>
              {s.value}
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <div className="work-card">
          <span className="eyebrow">Due soon</span>
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
            {dueSoon.length === 0 && <p style={{ fontSize: 13 }}>Nothing urgent — good sign.</p>}
            {dueSoon.slice(0, 6).map((t) => (
              <div key={t.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                <span>{t.title}</span>
                <span className="mono" style={{ color: "var(--text-faint)" }}>
                  {t.dueDate ? new Date(t.dueDate).toLocaleDateString() : ""}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="work-card">
          <span className="eyebrow">Status breakdown</span>
          <StatusBreakdownChart tasks={tasks} />
        </div>
      </div>
    </div>
  );
}
