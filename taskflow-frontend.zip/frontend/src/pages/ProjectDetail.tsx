import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { fetchTasks } from "@/store/slices/tasksSlice";
import { projectsApi } from "@/api/projects";
import { tasksApi } from "@/api/tasks";
import { TaskBoard } from "@/components/tasks/TaskBoard";
import { TaskFilterBar } from "@/components/tasks/TaskFilterBar";
import { TaskForm } from "@/components/tasks/TaskForm";
import { Modal } from "@/components/common/Modal";
import { Button } from "@/components/common/Button";
import { StatusBadge } from "@/components/common/StatusBadge";
import type { Project, Task } from "@/types";
import type { TaskFilters } from "@/api/tasks";

export default function ProjectDetail() {
  const { projectId } = useParams<{ projectId: string }>();
  const dispatch = useAppDispatch();
  const tasks = useAppSelector((state) => state.tasks.items);
  const [project, setProject] = useState<Project | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [filters, setFilters] = useState<TaskFilters>({});

  useEffect(() => {
    if (!projectId) return;
    projectsApi.get(projectId).then(setProject).catch(() => toast.error("Couldn't load project"));
  }, [projectId]);

  useEffect(() => {
    if (!projectId) return;
    dispatch(fetchTasks({ ...filters, projectId }));
  }, [dispatch, projectId, filters]);

  const handleFilterChange = useCallback((next: TaskFilters) => setFilters(next), []);

  async function handleExport(format: "csv" | "pdf") {
    if (!projectId) return;
    const blob = format === "csv" ? await tasksApi.exportCsv(projectId) : await tasksApi.exportPdf(projectId);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.name ?? "project"}-tasks.${format}`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${format.toUpperCase()}`);
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
        <div>
          <p className="eyebrow">{project ? "Project" : "Loading…"}</p>
          <h1 style={{ fontSize: 26, marginTop: 6 }}>{project?.name}</h1>
          <p style={{ fontSize: 13, marginTop: 4, maxWidth: 480 }}>{project?.description}</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Button variant="secondary" onClick={() => handleExport("csv")}>Export CSV</Button>
          <Button variant="secondary" onClick={() => handleExport("pdf")}>Export PDF</Button>
          <Button onClick={() => setCreateOpen(true)}>+ New task</Button>
        </div>
      </div>

      <TaskFilterBar onChange={handleFilterChange} />

      <TaskBoard tasks={tasks} onOpenTask={setSelectedTask} />

      <Modal title="New task" isOpen={createOpen} onClose={() => setCreateOpen(false)}>
        {projectId && <TaskForm projectId={projectId} onCreated={() => setCreateOpen(false)} />}
      </Modal>

      <Modal title={selectedTask?.title ?? ""} isOpen={Boolean(selectedTask)} onClose={() => setSelectedTask(null)}>
        {selectedTask && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <StatusBadge status={selectedTask.status} />
            <p style={{ fontSize: 14, color: "var(--text-primary)" }}>
              {selectedTask.description || "No description provided."}
            </p>
            <div className="mono" style={{ fontSize: 11, color: "var(--text-faint)" }}>
              Created {new Date(selectedTask.createdAt).toLocaleDateString()}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
