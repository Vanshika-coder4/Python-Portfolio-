import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div style={{ display: "grid", placeItems: "center", height: "100vh", textAlign: "center", padding: 24 }}>
      <div>
        <p className="eyebrow">Error 404</p>
        <h1 style={{ fontSize: 40, margin: "10px 0" }}>This route wasn't logged.</h1>
        <p style={{ marginBottom: 20 }}>The page you're after doesn't exist, or moved.</p>
        <Link to="/dashboard" className="btn btn-primary" style={{ textDecoration: "none" }}>
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
