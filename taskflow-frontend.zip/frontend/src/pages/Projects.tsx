import { useEffect, useState, type FormEvent } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { createProject, fetchProjects } from "@/store/slices/projectsSlice";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { Modal } from "@/components/common/Modal";
import { Field } from "@/components/common/Field";
import { Button } from "@/components/common/Button";

const SWATCHES = ["#f2a93b", "#3fbfad", "#8fb1ff", "#e5555a", "#c792ea"];

export default function Projects() {
  const dispatch = useAppDispatch();
  const { items, status } = useAppSelector((state) => state.projects);
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState(SWATCHES[0]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    dispatch(fetchProjects());
  }, [dispatch]);

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await dispatch(createProject({ name, description, color })).unwrap();
      setModalOpen(false);
      setName("");
      setDescription("");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <p className="eyebrow">Projects</p>
          <h1 style={{ fontSize: 26, marginTop: 6 }}>Every workstream in one shop floor.</h1>
        </div>
        <Button onClick={() => setModalOpen(true)}>+ New project</Button>
      </div>

      {status === "loading" && <p>Loading projects…</p>}

      {status === "loaded" && items.length === 0 && (
        <div className="work-card" style={{ textAlign: "center", padding: 40 }}>
          <p>No projects yet. Start one to open your first work order.</p>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 }}>
        {items.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>

      <Modal title="New project" isOpen={modalOpen} onClose={() => setModalOpen(false)}>
        <form onSubmit={handleCreate} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Field label="Project name" required value={name} onChange={(e) => setName(e.target.value)} />
          <div className="field">
            <label htmlFor="project-desc">Description</label>
            <textarea id="project-desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <label className="eyebrow" style={{ display: "block", marginBottom: 8 }}>Color</label>
            <div style={{ display: "flex", gap: 8 }}>
              {SWATCHES.map((swatch) => (
                <button
                  key={swatch}
                  type="button"
                  onClick={() => setColor(swatch)}
                  aria-label={`Choose color ${swatch}`}
                  style={{
                    width: 26,
                    height: 26,
                    borderRadius: 6,
                    background: swatch,
                    border: color === swatch ? "2px solid var(--text-primary)" : "2px solid transparent",
                    cursor: "pointer",
                  }}
                />
              ))}
            </div>
          </div>
          <Button type="submit" loading={submitting}>Create project</Button>
        </form>
      </Modal>
    </div>
  );
}
