import { useState, type FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { Field } from "@/components/common/Field";
import { Button } from "@/components/common/Button";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { login } from "@/store/slices/authSlice";

export default function Login() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { error, status } = useAppSelector((state) => state.auth);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  if (status === "authenticated") {
    const from = (location.state as { from?: Location })?.from?.pathname ?? "/dashboard";
    return <Navigate to={from} replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const result = await dispatch(login({ email, password }));
    if (login.fulfilled.match(result)) {
      navigate("/dashboard");
    }
  }

  return (
    <div className="auth-shell">
      <div className="auth-shell__aside">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" rx="7" fill="var(--accent-amber)" />
            <path d="M7 16h6l2-6 4 12 2-6h4" fill="none" stroke="#241705" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20 }}>TaskFlow</span>
        </div>
        <div>
          <p className="eyebrow" style={{ marginBottom: 10 }}>Route 04 / Team Ops</p>
          <h2 style={{ fontSize: 28, lineHeight: 1.3, marginBottom: 12 }}>
            Every task, tracked like a work order — from open to shipped.
          </h2>
          <p style={{ fontSize: 14 }}>
            Kanban boards, live updates, and reporting for teams who'd rather build than chase status updates.
          </p>
        </div>
        <p className="eyebrow">© {new Date().getFullYear()} TaskFlow — capstone project</p>
      </div>

      <div className="auth-shell__form">
        <form onSubmit={handleSubmit} style={{ width: "100%", maxWidth: 360, display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <h2 style={{ fontSize: 22, marginBottom: 4 }}>Sign in</h2>
            <p style={{ fontSize: 13 }}>Welcome back. Let's see what shipped overnight.</p>
          </div>

          <Field label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          <Field label="Password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />

          {error && (
            <p role="alert" className="field-error">{error}</p>
          )}

          <Button type="submit" loading={status === "loading"}>
            Sign in
          </Button>

          <p style={{ fontSize: 13, textAlign: "center" }}>
            No account? <Link to="/register" style={{ color: "var(--accent-amber)" }}>Create one</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
