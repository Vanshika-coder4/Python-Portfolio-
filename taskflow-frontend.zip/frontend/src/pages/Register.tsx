import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { Field } from "@/components/common/Field";
import { Button } from "@/components/common/Button";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { register } from "@/store/slices/authSlice";

export default function Register() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { error, status } = useAppSelector((state) => state.auth);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  if (status === "authenticated") {
    return <Navigate to="/dashboard" replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (fullName.trim().length < 2) errs.fullName = "Enter your full name";
    if (password.length < 8) errs.password = "Use at least 8 characters";
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const result = await dispatch(register({ fullName, email, password }));
    if (register.fulfilled.match(result)) {
      navigate("/dashboard");
    }
  }

  return (
    <div className="auth-shell">
      <div className="auth-shell__aside">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" rx="7" fill="var(--accent-amber)" />
            <path d="M7 16h6l2-6 4 12 2-6h4" fill="none" stroke="#241705" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20 }}>TaskFlow</span>
        </div>
        <div>
          <p className="eyebrow" style={{ marginBottom: 10 }}>Route 01 / Onboarding</p>
          <h2 style={{ fontSize: 28, lineHeight: 1.3 }}>
            Set up your workspace in under a minute.
          </h2>
        </div>
        <p className="eyebrow">© {new Date().getFullYear()} TaskFlow — capstone project</p>
      </div>

      <div className="auth-shell__form">
        <form onSubmit={handleSubmit} style={{ width: "100%", maxWidth: 360, display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <h2 style={{ fontSize: 22, marginBottom: 4 }}>Create your account</h2>
            <p style={{ fontSize: 13 }}>Free for teams of up to five.</p>
          </div>

          <Field label="Full name" required value={fullName} onChange={(e) => setFullName(e.target.value)} error={fieldErrors.fullName} autoComplete="name" />
          <Field label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          <Field label="Password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} error={fieldErrors.password} autoComplete="new-password" />

          {error && <p role="alert" className="field-error">{error}</p>}

          <Button type="submit" loading={status === "loading"}>
            Create account
          </Button>

          <p style={{ fontSize: 13, textAlign: "center" }}>
            Already have one? <Link to="/login" style={{ color: "var(--accent-amber)" }}>Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
