import { Link } from "react-router-dom";
import type { Project } from "@/types";

export function ProjectCard({ project }: { project: Project }) {
  const pct = project.taskCount === 0 ? 0 : Math.round((project.completedCount / project.taskCount) * 100);

  return (
    <Link to={`/projects/${project.id}`} style={{ textDecoration: "none", color: "inherit" }}>
      <div className="work-card" style={{ height: "100%" }}>
        <span className="work-card__tag mono">{pct}% DONE</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
          <span
            aria-hidden="true"
            style={{ width: 10, height: 10, borderRadius: 3, background: project.color, display: "inline-block" }}
          />
          <h3 style={{ fontSize: 16 }}>{project.name}</h3>
        </div>
        <p style={{ marginTop: 8, fontSize: 13, minHeight: 36 }}>{project.description}</p>

        <div
          style={{
            marginTop: 14,
            height: 6,
            borderRadius: 4,
            background: "var(--line-blueprint-soft)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              width: `${pct}%`,
              height: "100%",
              background: "var(--accent-teal)",
              transition: "width 300ms ease",
            }}
          />
        </div>

        <div className="mono" style={{ marginTop: 10, fontSize: 11, color: "var(--text-faint)" }}>
          {project.completedCount}/{project.taskCount} work orders closed
        </div>
      </div>
    </Link>
  );
}
