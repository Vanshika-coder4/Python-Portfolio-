import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { StatusBadge } from "../StatusBadge";

describe("StatusBadge", () => {
  it("renders the human-readable label for each status", () => {
    render(<StatusBadge status="in_progress" />);
    expect(screen.getByText("In progress")).toBeInTheDocument();
  });

  it("renders the done state distinctly", () => {
    render(<StatusBadge status="done" />);
    expect(screen.getByText("Done")).toBeInTheDocument();
  });
});
