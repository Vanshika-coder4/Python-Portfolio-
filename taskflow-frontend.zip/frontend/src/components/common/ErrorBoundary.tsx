import { Component, type ErrorInfo, type PropsWithChildren } from "react";

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<PropsWithChildren, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // In production this reports to the monitoring service (see README).
    console.error("Unhandled UI error:", error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ display: "grid", placeItems: "center", height: "100vh", padding: 24, textAlign: "center" }}>
          <div>
            <p className="eyebrow">Application error</p>
            <h1 style={{ fontSize: 24, margin: "10px 0" }}>Something broke on our end.</h1>
            <p style={{ marginBottom: 16 }}>Reloading usually fixes it. If it keeps happening, contact support.</p>
            <button className="btn btn-primary" onClick={() => window.location.reload()}>
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
