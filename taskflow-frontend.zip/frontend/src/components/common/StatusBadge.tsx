import clsx from "clsx";
import type { TaskStatus } from "@/types";

const LABELS: Record<TaskStatus, string> = {
  todo: "To do",
  in_progress: "In progress",
  review: "In review",
  done: "Done",
};

const CLASS_MAP: Record<TaskStatus, string> = {
  todo: "badge-todo",
  in_progress: "badge-progress",
  review: "badge-review",
  done: "badge-done",
};

export function StatusBadge({ status }: { status: TaskStatus }) {
  return (
    <span className={clsx("badge", CLASS_MAP[status])}>
      <span className="badge-dot" />
      {LABELS[status]}
    </span>
  );
}
