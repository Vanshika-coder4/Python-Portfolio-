import { type ButtonHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";
import { Spinner } from "./Spinner";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger";
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", loading = false, disabled, className, children, ...rest }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx("btn", `btn-${variant}`, className)}
        disabled={disabled || loading}
        aria-busy={loading}
        {...rest}
      >
        {loading && <Spinner size={14} />}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";
