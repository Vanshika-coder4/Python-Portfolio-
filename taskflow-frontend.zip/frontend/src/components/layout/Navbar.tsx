import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { toggleTheme } from "@/store/slices/uiSlice";
import { logout } from "@/store/slices/authSlice";
import { fetchNotifications } from "@/store/slices/notificationsSlice";
import { NotificationsPanel } from "./NotificationsPanel";

export function Navbar() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const theme = useAppSelector((state) => state.ui.theme);
  const user = useAppSelector((state) => state.auth.user);
  const unreadCount = useAppSelector((state) => state.notifications.unreadCount);
  const [panelOpen, setPanelOpen] = useState(false);

  useEffect(() => {
    dispatch(fetchNotifications());
  }, [dispatch]);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  async function handleLogout() {
    await dispatch(logout());
    navigate("/login");
  }

  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "14px clamp(16px, 4vw, 40px)",
        borderBottom: "1px solid var(--line-blueprint)",
        background: "var(--bg-panel)",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}
    >
      <div className="eyebrow">Workspace / Acme Team</div>

      <div style={{ display: "flex", alignItems: "center", gap: 12, position: "relative" }}>
        <button
          onClick={() => dispatch(toggleTheme())}
          aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          className="btn btn-secondary"
          style={{ padding: 8 }}
        >
          {theme === "dark" ? "☀" : "☾"}
        </button>

        <button
          onClick={() => setPanelOpen((o) => !o)}
          aria-label={`Notifications, ${unreadCount} unread`}
          className="btn btn-secondary"
          style={{ padding: 8, position: "relative" }}
        >
          🔔
          {unreadCount > 0 && (
            <span
              style={{
                position: "absolute",
                top: -4,
                right: -4,
                background: "var(--danger)",
                color: "#fff",
                borderRadius: 999,
                fontSize: 10,
                minWidth: 16,
                height: 16,
                display: "grid",
                placeItems: "center",
                fontFamily: "var(--font-mono)",
              }}
            >
              {unreadCount}
            </span>
          )}
        </button>
        {panelOpen && <NotificationsPanel onClose={() => setPanelOpen(false)} />}

        <div
          style={{
            width: 30,
            height: 30,
            borderRadius: "50%",
            background: "var(--accent-teal-dim)",
            color: "var(--accent-teal)",
            display: "grid",
            placeItems: "center",
            fontSize: 12,
            fontWeight: 700,
            fontFamily: "var(--font-mono)",
          }}
          title={user?.fullName}
        >
          {user?.fullName?.slice(0, 2).toUpperCase() ?? "?"}
        </div>

        <button onClick={handleLogout} className="btn btn-secondary">
          Sign out
        </button>
      </div>
    </header>
  );
}
