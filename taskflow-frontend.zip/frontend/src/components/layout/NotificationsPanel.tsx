import { formatDistanceToNow } from "date-fns";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { markNotificationRead } from "@/store/slices/notificationsSlice";

export function NotificationsPanel({ onClose }: { onClose: () => void }) {
  const dispatch = useAppDispatch();
  const items = useAppSelector((state) => state.notifications.items);

  return (
    <div
      role="menu"
      style={{
        position: "absolute",
        top: "calc(100% + 8px)",
        right: 0,
        width: 320,
        maxHeight: 380,
        overflowY: "auto",
        background: "var(--bg-panel-raised)",
        border: "1px solid var(--line-blueprint)",
        borderRadius: 10,
        boxShadow: "var(--shadow-card)",
        zIndex: 20,
      }}
    >
      <div style={{ padding: "12px 14px", borderBottom: "1px solid var(--line-blueprint)" }}>
        <strong style={{ fontSize: 13 }}>Notifications</strong>
      </div>

      {items.length === 0 && (
        <p style={{ padding: 16, fontSize: 13 }}>You're all caught up.</p>
      )}

      {items.map((n) => (
        <button
          key={n.id}
          onClick={() => {
            dispatch(markNotificationRead(n.id));
            onClose();
          }}
          style={{
            display: "block",
            width: "100%",
            textAlign: "left",
            padding: "10px 14px",
            background: n.read ? "transparent" : "var(--bg-panel)",
            border: "none",
            borderBottom: "1px solid var(--line-blueprint)",
            color: "var(--text-primary)",
            cursor: "pointer",
            fontSize: 13,
          }}
        >
          <div>{n.message}</div>
          <div className="eyebrow" style={{ marginTop: 4 }}>
            {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
          </div>
        </button>
      ))}
    </div>
  );
}
