import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { Navbar } from "./Navbar";
import { useWebSocket } from "@/hooks/useWebSocket";

export function Layout() {
  useWebSocket();

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-column">
        <Navbar />
        <div className="page-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
