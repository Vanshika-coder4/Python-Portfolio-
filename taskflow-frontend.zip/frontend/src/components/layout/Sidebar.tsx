import { NavLink } from "react-router-dom";
import clsx from "clsx";

const LINKS = [
  { to: "/dashboard", label: "Dashboard", glyph: "⌘" },
  { to: "/projects", label: "Projects", glyph: "▤" },
  { to: "/profile", label: "Profile", glyph: "◎" },
];

export function Sidebar() {
  return (
    <aside
      style={{
        borderRight: "1px solid var(--line-blueprint)",
        background: "var(--bg-panel)",
        padding: "24px 16px",
        display: "flex",
        flexDirection: "column",
        gap: 24,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "0 8px" }}>
        <svg width="22" height="22" viewBox="0 0 32 32" aria-hidden="true">
          <rect width="32" height="32" rx="7" fill="var(--accent-amber)" />
          <path
            d="M7 16h6l2-6 4 12 2-6h4"
            fill="none"
            stroke="#241705"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 17 }}>
          TaskFlow
        </span>
      </div>

      <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {LINKS.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              clsx("sidebar-link", isActive && "sidebar-link--active")
            }
            style={({ isActive }) => ({
              display: "flex",
              alignItems: "center",
              gap: 10,
              padding: "9px 12px",
              borderRadius: 6,
              textDecoration: "none",
              color: isActive ? "var(--text-primary)" : "var(--text-muted)",
              background: isActive ? "var(--bg-panel-raised)" : "transparent",
              fontSize: 14,
              fontWeight: 500,
              border: isActive ? "1px solid var(--line-blueprint)" : "1px solid transparent",
            })}
          >
            <span aria-hidden="true" style={{ fontFamily: "var(--font-mono)" }}>
              {link.glyph}
            </span>
            {link.label}
          </NavLink>
        ))}
      </nav>

      <div style={{ marginTop: "auto" }} className="eyebrow">
        v1.0.0 · capstone build
      </div>
    </aside>
  );
}
