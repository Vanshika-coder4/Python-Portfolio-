import { useState } from "react";
import type { Task, TaskStatus } from "@/types";
import { TaskCard } from "./TaskCard";
import { useAppDispatch } from "@/store/hooks";
import { moveTask } from "@/store/slices/tasksSlice";

const COLUMNS: { status: TaskStatus; label: string }[] = [
  { status: "todo", label: "To do" },
  { status: "in_progress", label: "In progress" },
  { status: "review", label: "In review" },
  { status: "done", label: "Done" },
];

interface TaskBoardProps {
  tasks: Task[];
  onOpenTask: (task: Task) => void;
}

export function TaskBoard({ tasks, onOpenTask }: TaskBoardProps) {
  const dispatch = useAppDispatch();
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<TaskStatus | null>(null);

  function handleDrop(status: TaskStatus) {
    if (draggingId) {
      dispatch(moveTask({ id: draggingId, status }));
    }
    setDraggingId(null);
    setDragOverColumn(null);
  }

  return (
    <div className="board">
      {COLUMNS.map((col) => {
        const columnTasks = tasks.filter((t) => t.status === col.status);
        return (
          <div
            key={col.status}
            className="board-column"
            onDragOver={(e) => {
              e.preventDefault();
              setDragOverColumn(col.status);
            }}
            onDragLeave={() => setDragOverColumn(null)}
            onDrop={() => handleDrop(col.status)}
          >
            <div className="board-column__header">
              <span className="eyebrow">{col.label}</span>
              <span className="mono" style={{ fontSize: 11, color: "var(--text-faint)" }}>
                {columnTasks.length}
              </span>
            </div>
            <div
              className="board-column__cards"
              style={{
                outline: dragOverColumn === col.status ? "1px dashed var(--accent-amber)" : "none",
                borderRadius: 8,
                padding: dragOverColumn === col.status ? 4 : 0,
              }}
            >
              {columnTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onOpen={onOpenTask}
                  onDragStart={setDraggingId}
                />
              ))}
              {columnTasks.length === 0 && (
                <p style={{ fontSize: 12, padding: "8px 2px" }}>No tasks routed here yet.</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
