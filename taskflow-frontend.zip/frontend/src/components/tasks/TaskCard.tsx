import { format } from "date-fns";
import type { Task } from "@/types";

const PRIORITY_GLYPH: Record<Task["priority"], string> = {
  low: "▽",
  medium: "◇",
  high: "△",
  urgent: "▲",
};

interface TaskCardProps {
  task: Task;
  onOpen: (task: Task) => void;
  onDragStart: (taskId: string) => void;
}

export function TaskCard({ task, onOpen, onDragStart }: TaskCardProps) {
  return (
    <div
      className="work-card"
      draggable
      onDragStart={() => onDragStart(task.id)}
      role="button"
      tabIndex={0}
      onClick={() => onOpen(task)}
      onKeyDown={(e) => {
        if (e.key === "Enter") onOpen(task);
      }}
    >
      <span className="work-card__tag mono">WO-{task.id.slice(0, 6).toUpperCase()}</span>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginTop: 6 }}>
        <h4 style={{ fontSize: 14, lineHeight: 1.4 }}>{task.title}</h4>
        <span
          title={`Priority: ${task.priority}`}
          style={{ color: "var(--accent-amber)", fontSize: 13 }}
        >
          {PRIORITY_GLYPH[task.priority]}
        </span>
      </div>

      {task.tags.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
          {task.tags.map((tag) => (
            <span key={tag} className="eyebrow" style={{ border: "1px solid var(--line-blueprint)", borderRadius: 4, padding: "1px 6px" }}>
              {tag}
            </span>
          ))}
        </div>
      )}

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 12,
          fontSize: 11,
          color: "var(--text-faint)",
        }}
        className="mono"
      >
        <span>{task.dueDate ? format(new Date(task.dueDate), "MMM d") : "No due date"}</span>
        <span>{task.commentCount > 0 ? `💬 ${task.commentCount}` : ""}</span>
      </div>
    </div>
  );
}
