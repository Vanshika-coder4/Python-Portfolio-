import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Field } from "@/components/common/Field";
import { Button } from "@/components/common/Button";
import { useAppDispatch } from "@/store/hooks";
import { createTask } from "@/store/slices/tasksSlice";
import type { TaskPriority } from "@/types";

const taskSchema = z.object({
  title: z.string().min(3, "Title needs at least 3 characters").max(120),
  description: z.string().max(2000).optional().default(""),
  priority: z.enum(["low", "medium", "high", "urgent"]),
  dueDate: z.string().optional(),
});

interface TaskFormProps {
  projectId: string;
  onCreated: () => void;
}

export function TaskForm({ projectId, onCreated }: TaskFormProps) {
  const dispatch = useAppDispatch();
  const [values, setValues] = useState({
    title: "",
    description: "",
    priority: "medium" as TaskPriority,
    dueDate: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const result = taskSchema.safeParse(values);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of result.error.issues) {
        fieldErrors[issue.path[0] as string] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }

    setSubmitting(true);
    try {
      await dispatch(
        createTask({
          projectId,
          title: result.data.title,
          description: result.data.description,
          priority: result.data.priority,
          dueDate: result.data.dueDate || null,
        })
      ).unwrap();
      onCreated();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Field
        label="Title"
        value={values.title}
        onChange={(e) => setValues((v) => ({ ...v, title: e.target.value }))}
        error={errors.title}
        placeholder="e.g. Fix checkout redirect bug"
      />

      <div className="field">
        <label htmlFor="task-description">Description</label>
        <textarea
          id="task-description"
          rows={3}
          value={values.description}
          onChange={(e) => setValues((v) => ({ ...v, description: e.target.value }))}
        />
      </div>

      <div style={{ display: "flex", gap: 12 }}>
        <div className="field" style={{ flex: 1 }}>
          <label htmlFor="task-priority">Priority</label>
          <select
            id="task-priority"
            value={values.priority}
            onChange={(e) =>
              setValues((v) => ({ ...v, priority: e.target.value as TaskPriority }))
            }
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <Field
          label="Due date"
          type="date"
          value={values.dueDate}
          onChange={(e) => setValues((v) => ({ ...v, dueDate: e.target.value }))}
          style={{ flex: 1 }}
        />
      </div>

      <Button type="submit" loading={submitting}>
        Create task
      </Button>
    </form>
  );
}
