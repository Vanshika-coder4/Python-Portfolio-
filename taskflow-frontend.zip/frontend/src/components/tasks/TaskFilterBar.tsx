import { useEffect, useState } from "react";
import { useDebounce } from "@/hooks/useDebounce";
import type { TaskFilters } from "@/api/tasks";
import type { TaskPriority, TaskStatus } from "@/types";

interface TaskFilterBarProps {
  onChange: (filters: TaskFilters) => void;
}

export function TaskFilterBar({ onChange }: TaskFilterBarProps) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<TaskStatus | "">("");
  const [priority, setPriority] = useState<TaskPriority | "">("");
  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    onChange({
      search: debouncedSearch || undefined,
      status: (status || undefined) as TaskStatus | undefined,
      priority: (priority || undefined) as TaskPriority | undefined,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, status, priority]);

  return (
    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 18 }}>
      <input
        aria-label="Search tasks"
        placeholder="Search work orders…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          flex: "1 1 220px",
          background: "var(--bg-panel-raised)",
          border: "1px solid var(--line-blueprint)",
          borderRadius: 6,
          padding: "9px 12px",
          color: "var(--text-primary)",
        }}
      />
      <select
        aria-label="Filter by status"
        value={status}
        onChange={(e) => setStatus(e.target.value as TaskStatus | "")}
        style={{ background: "var(--bg-panel-raised)", border: "1px solid var(--line-blueprint)", borderRadius: 6, padding: "9px 12px", color: "var(--text-primary)" }}
      >
        <option value="">All statuses</option>
        <option value="todo">To do</option>
        <option value="in_progress">In progress</option>
        <option value="review">In review</option>
        <option value="done">Done</option>
      </select>
      <select
        aria-label="Filter by priority"
        value={priority}
        onChange={(e) => setPriority(e.target.value as TaskPriority | "")}
        style={{ background: "var(--bg-panel-raised)", border: "1px solid var(--line-blueprint)", borderRadius: 6, padding: "9px 12px", color: "var(--text-primary)" }}
      >
        <option value="">All priorities</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
        <option value="urgent">Urgent</option>
      </select>
    </div>
  );
}
