import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { Task } from "@/types";

const COLORS: Record<Task["status"], string> = {
  todo: "#5c6784",
  in_progress: "#f2a93b",
  review: "#8fb1ff",
  done: "#3fbfad",
};

const LABELS: Record<Task["status"], string> = {
  todo: "To do",
  in_progress: "In progress",
  review: "In review",
  done: "Done",
};

export function StatusBreakdownChart({ tasks }: { tasks: Task[] }) {
  const data = (Object.keys(LABELS) as Task["status"][]).map((status) => ({
    name: LABELS[status],
    value: tasks.filter((t) => t.status === status).length,
    color: COLORS[status],
  }));

  const hasData = data.some((d) => d.value > 0);

  return (
    <div style={{ width: "100%", height: 220 }}>
      {!hasData ? (
        <p style={{ paddingTop: 80, textAlign: "center" }}>No tasks yet to chart.</p>
      ) : (
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius={55}
              outerRadius={80}
              paddingAngle={3}
            >
              {data.map((entry) => (
                <Cell key={entry.name} fill={entry.color} stroke="none" />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                background: "var(--bg-panel-raised)",
                border: "1px solid var(--line-blueprint)",
                borderRadius: 8,
                fontSize: 12,
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
