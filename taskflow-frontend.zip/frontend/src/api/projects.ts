import { apiClient } from "./client";
import type { PaginatedResponse, Project } from "@/types";

export interface CreateProjectPayload {
  name: string;
  description: string;
  color: string;
}

export const projectsApi = {
  async list(page = 1, pageSize = 20): Promise<PaginatedResponse<Project>> {
    const { data } = await apiClient.get("/projects", { params: { page, pageSize } });
    return data;
  },

  async get(id: string): Promise<Project> {
    const { data } = await apiClient.get(`/projects/${id}`);
    return data;
  },

  async create(payload: CreateProjectPayload): Promise<Project> {
    const { data } = await apiClient.post("/projects", payload);
    return data;
  },

  async update(id: string, payload: Partial<CreateProjectPayload>): Promise<Project> {
    const { data } = await apiClient.patch(`/projects/${id}`, payload);
    return data;
  },

  async remove(id: string): Promise<void> {
    await apiClient.delete(`/projects/${id}`);
  },
};
