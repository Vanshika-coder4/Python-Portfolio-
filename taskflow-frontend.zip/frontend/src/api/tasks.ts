import { apiClient } from "./client";
import type { Task, TaskPriority, TaskStatus } from "@/types";

export interface TaskFilters {
  projectId?: string;
  status?: TaskStatus;
  priority?: TaskPriority;
  assigneeId?: string;
  search?: string;
}

export interface CreateTaskPayload {
  projectId: string;
  title: string;
  description: string;
  priority: TaskPriority;
  assigneeId?: string | null;
  dueDate?: string | null;
  tags?: string[];
}

export const tasksApi = {
  async list(filters: TaskFilters = {}): Promise<Task[]> {
    const { data } = await apiClient.get("/tasks", { params: filters });
    return data;
  },

  async get(id: string): Promise<Task> {
    const { data } = await apiClient.get(`/tasks/${id}`);
    return data;
  },

  async create(payload: CreateTaskPayload): Promise<Task> {
    const { data } = await apiClient.post("/tasks", payload);
    return data;
  },

  async update(id: string, payload: Partial<CreateTaskPayload & { status: TaskStatus }>): Promise<Task> {
    const { data } = await apiClient.patch(`/tasks/${id}`, payload);
    return data;
  },

  async updateStatus(id: string, status: TaskStatus): Promise<Task> {
    const { data } = await apiClient.patch(`/tasks/${id}/status`, { status });
    return data;
  },

  async remove(id: string): Promise<void> {
    await apiClient.delete(`/tasks/${id}`);
  },

  async exportCsv(projectId: string): Promise<Blob> {
    const { data } = await apiClient.get(`/projects/${projectId}/export/csv`, {
      responseType: "blob",
    });
    return data;
  },

  async exportPdf(projectId: string): Promise<Blob> {
    const { data } = await apiClient.get(`/projects/${projectId}/export/pdf`, {
      responseType: "blob",
    });
    return data;
  },
};
