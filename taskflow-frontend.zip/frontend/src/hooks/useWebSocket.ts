import { useEffect, useRef } from "react";
import { io, type Socket } from "socket.io-client";
import toast from "react-hot-toast";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { getStoredTokens } from "@/api/client";
import { taskUpdatedFromSocket, taskRemovedFromSocket } from "@/store/slices/tasksSlice";
import { notificationReceived } from "@/store/slices/notificationsSlice";
import type { Notification, Task } from "@/types";

const WS_URL = import.meta.env.VITE_WS_URL ?? "/";

/**
 * Opens a single authenticated Socket.IO connection for the lifetime of the
 * session and wires server events into Redux. Mount once near the app root.
 */
export function useWebSocket() {
  const dispatch = useAppDispatch();
  const user = useAppSelector((state) => state.auth.user);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!user) return;
    const tokens = getStoredTokens();
    if (!tokens) return;

    const socket = io(WS_URL, {
      path: "/socket.io",
      auth: { token: tokens.accessToken },
      transports: ["websocket"],
      reconnectionAttempts: 5,
    });
    socketRef.current = socket;

    socket.on("task:updated", (task: Task) => {
      dispatch(taskUpdatedFromSocket(task));
    });

    socket.on("task:deleted", (taskId: string) => {
      dispatch(taskRemovedFromSocket(taskId));
    });

    socket.on("notification:new", (notification: Notification) => {
      dispatch(notificationReceived(notification));
      toast(notification.message, { icon: "🔔" });
    });

    socket.on("connect_error", () => {
      // Silent retry; socket.io handles backoff automatically.
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [user, dispatch]);

  return socketRef;
}
