import { useAppSelector } from "@/store/hooks";

export function useAuth() {
  const { user, status, error } = useAppSelector((state) => state.auth);
  return {
    user,
    isAuthenticated: Boolean(user),
    isLoading: status === "loading",
    error,
  };
}
