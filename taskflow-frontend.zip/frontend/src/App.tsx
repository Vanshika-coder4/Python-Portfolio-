import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { AppRoutes } from "@/routes/AppRoutes";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AppRoutes />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: "var(--bg-panel-raised)",
              color: "var(--text-primary)",
              border: "1px solid var(--line-blueprint)",
              fontSize: 13,
            },
          }}
        />
      </BrowserRouter>
    </ErrorBoundary>
  );
}
