import { type PropsWithChildren, useEffect } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { fetchCurrentUser } from "@/store/slices/authSlice";
import { getStoredTokens } from "@/api/client";
import { Spinner } from "@/components/common/Spinner";

export function ProtectedRoute({ children }: PropsWithChildren) {
  const dispatch = useAppDispatch();
  const location = useLocation();
  const { user, status } = useAppSelector((state) => state.auth);
  const hasTokens = Boolean(getStoredTokens());

  useEffect(() => {
    if (hasTokens && !user && status === "idle") {
      dispatch(fetchCurrentUser());
    }
  }, [hasTokens, user, status, dispatch]);

  if (!hasTokens) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (!user && status === "loading") {
    return (
      <div style={{ display: "grid", placeItems: "center", height: "100vh" }}>
        <Spinner />
      </div>
    );
  }

  if (!user && status === "error") {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return <>{children}</>;
}
