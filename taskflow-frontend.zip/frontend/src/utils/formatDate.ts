import { format, formatDistanceToNow, isPast } from "date-fns";

export function formatDueDate(iso: string | null): string {
  if (!iso) return "No due date";
  return format(new Date(iso), "MMM d, yyyy");
}

export function formatRelative(iso: string): string {
  return formatDistanceToNow(new Date(iso), { addSuffix: true });
}

export function isOverdue(iso: string | null, status: string): boolean {
  if (!iso || status === "done") return false;
  return isPast(new Date(iso));
}
