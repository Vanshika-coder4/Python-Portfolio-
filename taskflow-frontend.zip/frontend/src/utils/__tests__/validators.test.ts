import { describe, expect, it } from "vitest";
import { isStrongPassword, isValidEmail, truncate } from "../validators";

describe("isValidEmail", () => {
  it("accepts well-formed addresses", () => {
    expect(isValidEmail("jane@taskflow.app")).toBe(true);
  });

  it("rejects missing @ or domain", () => {
    expect(isValidEmail("jane.taskflow")).toBe(false);
    expect(isValidEmail("jane@")).toBe(false);
  });
});

describe("isStrongPassword", () => {
  it("requires at least 8 chars with a letter and a number", () => {
    expect(isStrongPassword("abc123456")).toBe(true);
    expect(isStrongPassword("short1")).toBe(false);
    expect(isStrongPassword("alllettersnodigits")).toBe(false);
  });
});

describe("truncate", () => {
  it("leaves short strings untouched", () => {
    expect(truncate("hello", 10)).toBe("hello");
  });

  it("truncates and appends an ellipsis", () => {
    expect(truncate("a very long task title indeed", 10)).toBe("a very lo…");
  });
});
