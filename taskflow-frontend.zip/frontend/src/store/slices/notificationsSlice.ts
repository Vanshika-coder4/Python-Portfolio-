import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { apiClient, extractApiErrorMessage } from "@/api/client";
import type { Notification } from "@/types";

interface NotificationsState {
  items: Notification[];
  unreadCount: number;
  status: "idle" | "loading" | "loaded" | "error";
}

const initialState: NotificationsState = {
  items: [],
  unreadCount: 0,
  status: "idle",
};

export const fetchNotifications = createAsyncThunk(
  "notifications/fetchAll",
  async (_: void, { rejectWithValue }) => {
    try {
      const { data } = await apiClient.get<Notification[]>("/notifications");
      return data;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const markNotificationRead = createAsyncThunk(
  "notifications/markRead",
  async (id: string) => {
    await apiClient.patch(`/notifications/${id}`, { read: true });
    return id;
  }
);

const notificationsSlice = createSlice({
  name: "notifications",
  initialState,
  reducers: {
    // Pushed live from the WebSocket hook.
    notificationReceived(state, action: PayloadAction<Notification>) {
      state.items.unshift(action.payload);
      state.unreadCount += 1;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchNotifications.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchNotifications.fulfilled, (state, action) => {
        state.status = "loaded";
        state.items = action.payload;
        state.unreadCount = action.payload.filter((n) => !n.read).length;
      })
      .addCase(markNotificationRead.fulfilled, (state, action) => {
        const n = state.items.find((item) => item.id === action.payload);
        if (n && !n.read) {
          n.read = true;
          state.unreadCount = Math.max(0, state.unreadCount - 1);
        }
      });
  },
});

export const { notificationReceived } = notificationsSlice.actions;
export default notificationsSlice.reducer;
