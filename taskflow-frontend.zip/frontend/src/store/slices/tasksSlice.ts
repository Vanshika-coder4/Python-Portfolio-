import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { tasksApi, type CreateTaskPayload, type TaskFilters } from "@/api/tasks";
import { extractApiErrorMessage } from "@/api/client";
import type { Task, TaskStatus } from "@/types";

interface TasksState {
  items: Task[];
  status: "idle" | "loading" | "loaded" | "error";
  error: string | null;
  filters: TaskFilters;
}

const initialState: TasksState = {
  items: [],
  status: "idle",
  error: null,
  filters: {},
};

export const fetchTasks = createAsyncThunk(
  "tasks/fetchAll",
  async (filters: TaskFilters, { rejectWithValue }) => {
    try {
      return await tasksApi.list(filters);
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const createTask = createAsyncThunk(
  "tasks/create",
  async (payload: CreateTaskPayload, { rejectWithValue }) => {
    try {
      return await tasksApi.create(payload);
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

// Optimistic: board reorders instantly, then confirms with the server.
export const moveTask = createAsyncThunk(
  "tasks/move",
  async ({ id, status }: { id: string; status: TaskStatus }, { rejectWithValue }) => {
    try {
      return await tasksApi.updateStatus(id, status);
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const deleteTask = createAsyncThunk(
  "tasks/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      await tasksApi.remove(id);
      return id;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

const tasksSlice = createSlice({
  name: "tasks",
  initialState,
  reducers: {
    setFilters(state, action: PayloadAction<TaskFilters>) {
      state.filters = { ...state.filters, ...action.payload };
    },
    // Applied by the WebSocket hook when another user moves a task.
    taskUpdatedFromSocket(state, action: PayloadAction<Task>) {
      const idx = state.items.findIndex((t) => t.id === action.payload.id);
      if (idx >= 0) state.items[idx] = action.payload;
      else state.items.unshift(action.payload);
    },
    taskRemovedFromSocket(state, action: PayloadAction<string>) {
      state.items = state.items.filter((t) => t.id !== action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTasks.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchTasks.fulfilled, (state, action) => {
        state.status = "loaded";
        state.items = action.payload;
      })
      .addCase(fetchTasks.rejected, (state, action) => {
        state.status = "error";
        state.error = action.payload as string;
      })
      .addCase(createTask.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      })
      .addCase(moveTask.pending, (state, action) => {
        const task = state.items.find((t) => t.id === action.meta.arg.id);
        if (task) task.status = action.meta.arg.status;
      })
      .addCase(moveTask.fulfilled, (state, action) => {
        const idx = state.items.findIndex((t) => t.id === action.payload.id);
        if (idx >= 0) state.items[idx] = action.payload;
      })
      .addCase(deleteTask.fulfilled, (state, action) => {
        state.items = state.items.filter((t) => t.id !== action.payload);
      });
  },
});

export const { setFilters, taskUpdatedFromSocket, taskRemovedFromSocket } = tasksSlice.actions;
export default tasksSlice.reducer;
