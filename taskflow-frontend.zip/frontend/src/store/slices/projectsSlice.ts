import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { projectsApi, type CreateProjectPayload } from "@/api/projects";
import { extractApiErrorMessage } from "@/api/client";
import type { Project } from "@/types";

interface ProjectsState {
  items: Project[];
  status: "idle" | "loading" | "loaded" | "error";
  error: string | null;
}

const initialState: ProjectsState = {
  items: [],
  status: "idle",
  error: null,
};

export const fetchProjects = createAsyncThunk(
  "projects/fetchAll",
  async (_: void, { rejectWithValue }) => {
    try {
      const res = await projectsApi.list();
      return res.items;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const createProject = createAsyncThunk(
  "projects/create",
  async (payload: CreateProjectPayload, { rejectWithValue }) => {
    try {
      return await projectsApi.create(payload);
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const deleteProject = createAsyncThunk(
  "projects/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      await projectsApi.remove(id);
      return id;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

const projectsSlice = createSlice({
  name: "projects",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProjects.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchProjects.fulfilled, (state, action) => {
        state.status = "loaded";
        state.items = action.payload;
      })
      .addCase(fetchProjects.rejected, (state, action) => {
        state.status = "error";
        state.error = action.payload as string;
      })
      .addCase(createProject.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      })
      .addCase(deleteProject.fulfilled, (state, action) => {
        state.items = state.items.filter((p) => p.id !== action.payload);
      });
  },
});

export default projectsSlice.reducer;
