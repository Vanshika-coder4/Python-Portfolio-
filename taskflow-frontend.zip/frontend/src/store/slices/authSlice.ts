import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { authApi, type LoginPayload, type RegisterPayload } from "@/api/auth";
import { clearTokens, getStoredTokens, storeTokens } from "@/api/client";
import { extractApiErrorMessage } from "@/api/client";
import type { User } from "@/types";

interface AuthState {
  user: User | null;
  status: "idle" | "loading" | "authenticated" | "error";
  error: string | null;
}

const initialState: AuthState = {
  user: null,
  status: "idle",
  error: null,
};

export const login = createAsyncThunk(
  "auth/login",
  async (payload: LoginPayload, { rejectWithValue }) => {
    try {
      const { user, tokens } = await authApi.login(payload);
      storeTokens(tokens);
      return user;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const register = createAsyncThunk(
  "auth/register",
  async (payload: RegisterPayload, { rejectWithValue }) => {
    try {
      const { user, tokens } = await authApi.register(payload);
      storeTokens(tokens);
      return user;
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const fetchCurrentUser = createAsyncThunk(
  "auth/fetchCurrentUser",
  async (_: void, { rejectWithValue }) => {
    if (!getStoredTokens()) return rejectWithValue("No session");
    try {
      return await authApi.me();
    } catch (err) {
      return rejectWithValue(extractApiErrorMessage(err));
    }
  }
);

export const logout = createAsyncThunk("auth/logout", async () => {
  try {
    await authApi.logout();
  } finally {
    clearTokens();
  }
});

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    clearAuthError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(register.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchCurrentUser.pending, (state) => {
        state.status = "loading";
      });

    builder.addMatcher(
      (action): action is PayloadAction<User> =>
        [login.fulfilled.type, register.fulfilled.type, fetchCurrentUser.fulfilled.type].includes(
          action.type
        ),
      (state, action) => {
        state.status = "authenticated";
        state.user = action.payload;
        state.error = null;
      }
    );

    builder.addMatcher(
      (action) =>
        [login.rejected.type, register.rejected.type, fetchCurrentUser.rejected.type].includes(
          action.type
        ),
      (state, action) => {
        state.status = "error";
        state.user = null;
        state.error = (action as PayloadAction<string>).payload ?? "Authentication failed";
      }
    );

    builder.addCase(logout.fulfilled, (state) => {
      state.status = "idle";
      state.user = null;
    });
  },
});

export const { clearAuthError } = authSlice.actions;
export default authSlice.reducer;
