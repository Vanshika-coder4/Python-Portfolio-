import { describe, expect, it, beforeEach } from "vitest";
import uiReducer, { toggleSidebar, toggleTheme } from "../uiSlice";

describe("uiSlice", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it("toggles between dark and light theme", () => {
    const initial = { theme: "dark" as const, sidebarOpen: true };
    const next = uiReducer(initial, toggleTheme());
    expect(next.theme).toBe("light");

    const nextAgain = uiReducer(next, toggleTheme());
    expect(nextAgain.theme).toBe("dark");
  });

  it("persists the chosen theme to localStorage", () => {
    const initial = { theme: "dark" as const, sidebarOpen: true };
    uiReducer(initial, toggleTheme());
    expect(localStorage.getItem("taskflow.theme")).toBe("light");
  });

  it("toggles sidebar visibility", () => {
    const initial = { theme: "dark" as const, sidebarOpen: true };
    const next = uiReducer(initial, toggleSidebar());
    expect(next.sidebarOpen).toBe(false);
  });
});
