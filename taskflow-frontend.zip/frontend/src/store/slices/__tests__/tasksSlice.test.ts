import { describe, expect, it } from "vitest";
import tasksReducer, { setFilters, taskRemovedFromSocket, taskUpdatedFromSocket } from "../tasksSlice";
import type { Task } from "@/types";

const sampleTask: Task = {
  id: "t1",
  projectId: "p1",
  title: "Wire up the dashboard",
  description: "",
  status: "todo",
  priority: "medium",
  assigneeId: null,
  dueDate: null,
  tags: [],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  commentCount: 0,
};

describe("tasksSlice", () => {
  it("merges filter updates instead of replacing them", () => {
    const initial = { items: [], status: "idle" as const, error: null, filters: { search: "bug" } };
    const next = tasksReducer(initial, setFilters({ status: "todo" }));
    expect(next.filters).toEqual({ search: "bug", status: "todo" });
  });

  it("applies a task update pushed over the socket", () => {
    const initial = { items: [sampleTask], status: "loaded" as const, error: null, filters: {} };
    const updated = { ...sampleTask, status: "done" as const };
    const next = tasksReducer(initial, taskUpdatedFromSocket(updated));
    expect(next.items[0].status).toBe("done");
  });

  it("inserts a socket-pushed task it hasn't seen yet", () => {
    const initial = { items: [], status: "loaded" as const, error: null, filters: {} };
    const next = tasksReducer(initial, taskUpdatedFromSocket(sampleTask));
    expect(next.items).toHaveLength(1);
  });

  it("removes a task deleted by another collaborator", () => {
    const initial = { items: [sampleTask], status: "loaded" as const, error: null, filters: {} };
    const next = tasksReducer(initial, taskRemovedFromSocket("t1"));
    expect(next.items).toHaveLength(0);
  });
});
